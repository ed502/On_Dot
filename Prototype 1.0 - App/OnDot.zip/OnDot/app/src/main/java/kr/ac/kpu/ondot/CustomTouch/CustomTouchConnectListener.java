package kr.ac.kpu.ondot.CustomTouch;

import android.view.MotionEvent;

public interface CustomTouchConnectListener {

    void touchEvent(MotionEvent event);
}
