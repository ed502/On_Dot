package kr.ac.kpu.ondot.CustomTouch;

public interface CustomTouchEventListener {
    void onOneFingerFunction(FingerFunctionType fingerFunctionType);
    void onTwoFingerFunction(FingerFunctionType fingerFunctionType);
}
