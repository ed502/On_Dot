package kr.ac.kpu.ondot.CustomTouch;


// 사용자의 터치를 타입별로 분류

public enum TouchType {

    NONE_TYPE, PERMISSION_CHECK_TYPE
}
