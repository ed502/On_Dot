package kr.ac.kpu.ondot.PermissionModule;

public interface PermissionCancelListener {
    void permissionCancel();
}
