package kr.ac.kpu.ondot.Quiz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import kr.ac.kpu.ondot.R;


public class QuizFirst extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_first);
    }
}
