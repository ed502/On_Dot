package kr.ac.kpu.ondot;

public class Screen {
    public static int displayX; // 화면의 가로
    public static int displayY; // 화면의 세로
}
