package kr.ac.kpu.ondot.VoiceModule;

public interface VoicePlayerStopListener {
    void voicePlayerStop();
}
